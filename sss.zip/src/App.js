import logo from './logo.svg';
import './App.css';
import Users from "./component/Users/users";

function App() {
  return (
    <div className="App">
     <Users/>
    </div>
  );
}

export default App;
